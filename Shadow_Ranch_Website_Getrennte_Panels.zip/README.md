# Shadow Ranch Website

- Admin-Panel mit Code `1583`: Bewerbungen ansehen/verwalten + Bilder hinzufügen/löschen.
- Webseitenverwaltung mit Code `7260`: nur Bilder hinzufügen/löschen; Bewerbungen sind dort nicht sichtbar.
- Beide Bereiche sind unabhängig.

Start: `npm install` und `npm start`.
